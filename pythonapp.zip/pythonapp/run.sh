#!/bin/bash
# Install required packages
pip install -r requirements.txt

# Run the Python script
python app.py

